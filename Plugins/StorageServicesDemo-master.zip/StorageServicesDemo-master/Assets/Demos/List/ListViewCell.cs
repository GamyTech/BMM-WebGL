﻿using UnityEngine.UI;
using Tacticsoft;

public class ListViewCell : TableViewCell
{
	public Text Name;
	public Button Delete;
}
