﻿using System;

[Serializable]
public class Scene
{
	public Level[] levels;
}