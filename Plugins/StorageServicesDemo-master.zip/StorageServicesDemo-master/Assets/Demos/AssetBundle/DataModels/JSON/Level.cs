﻿using System;

[Serializable]
public class Level
{
	public int number;
	public Prefab[] prefabs;
}